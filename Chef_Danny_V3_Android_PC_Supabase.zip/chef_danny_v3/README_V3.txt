CHEF DANNY LA HUECA — V3

OBJETIVO
V3 convierte el prototipo en una aplicación preparada para trabajar con una base de datos online y sincronizar Android + PC.

INCLUYE
- Menú online.
- Pedidos online.
- Productos y categorías sin límite artificial del programa.
- Cocina/KDS básico.
- Sincronización en tiempo real de pedidos mediante Supabase Realtime.
- Administración protegida con Supabase Auth (email + contraseña).
- Cuenta/factura interna: Pendiente / Pagada / Cancelada.
- QR de la cuenta y enlace público.
- WhatsApp para enviar pedido/cuenta.
- Mesas con QR.
- Delivery / para llevar / consumo en local.
- Ventas.
- APK Android preparada como proyecto Android Studio.
- Notificaciones nativas de Android cuando la app recibe una actualización mientras está abierta.
- Sin SRI.

IMPORTANTE SOBRE EL APK
El paquete incluye el proyecto Android listo para abrir en Android Studio y compilar. En este entorno no hay Android SDK/Gradle instalado, así que no se adjunta un APK binario ya compilado.

PASO 1 — CREAR LA BASE ONLINE
1. Crea un proyecto en Supabase.
2. Abre SQL Editor.
3. Ejecuta COMPLETO: supabase_schema.sql
4. En Authentication > Users crea el usuario administrador con email y contraseña.
5. En Project Settings > API copia Project URL y anon public key.
6. Edita web/config.js y android/app/src/main/assets/config.js con esos dos valores.

PASO 2 — PROBAR EN PC
Sirve la carpeta web desde un servidor local (no abras index.html con file:// si vas a usar Supabase). Por ejemplo, con Python:
python -m http.server 8080 --directory web
Luego abre http://localhost:8080

PASO 3 — COMPILAR APK
1. Abre la carpeta android/ en Android Studio.
2. Espera a que Gradle sincronice.
3. Build > Build APK(s).
4. Android Studio generará el APK en app/build/outputs/apk/.

REQUISITO DE SINCRONIZACIÓN
PC y Android deben usar el mismo proyecto Supabase y la misma configuración de config.js. Los pedidos se almacenan online y los cambios de pedidos se transmiten mediante Realtime.

SEGURIDAD
- El cliente NO puede escribir directamente los precios: create_order toma precios desde la base.
- La administración usa Supabase Auth.
- El cliente ve una cuenta pública mediante un token aleatorio, no mediante el ID interno.
- Para producción conviene separar roles de administrador/cocina/caja y endurecer RLS antes de abrir el sistema a terceros.
