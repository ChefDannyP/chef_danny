// CONFIGURACIÓN V3
// Reemplaza estos dos valores por los de tu proyecto Supabase.
window.CHEF_DANNY_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  SUPABASE_ANON_KEY: 'TU_ANON_KEY'
};
