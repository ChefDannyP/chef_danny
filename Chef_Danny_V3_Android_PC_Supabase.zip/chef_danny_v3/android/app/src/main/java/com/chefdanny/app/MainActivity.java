package com.chefdanny.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.Activity;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView web;
    private static final String CHANNEL="chef_danny_orders";
    @Override public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10); createChannel();
        web=new WebView(this); web.setBackgroundColor(Color.WHITE); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setDatabaseEnabled(true); web.getSettings().setMediaPlaybackRequiresUserGesture(false); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Pedidos Chef Danny",NotificationManager.IMPORTANCE_HIGH);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    public class Bridge { @JavascriptInterface public void notify(String text){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return; android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(MainActivity.this,CHANNEL):new android.app.Notification.Builder(MainActivity.this); b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Chef Danny").setContentText(text).setAutoCancel(true); getSystemService(NotificationManager.class).notify((int)System.currentTimeMillis(),b.build()); } }
    @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
}
